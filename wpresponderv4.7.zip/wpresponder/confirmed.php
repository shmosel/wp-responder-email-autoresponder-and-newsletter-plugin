<?php
include "../../../wp-config.php";
require "templates/confirmed.html";

?>
