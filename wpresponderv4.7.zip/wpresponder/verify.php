<?php
include "../../../wp-config.php";
require "templates/confirm_subscription.html";
?>
